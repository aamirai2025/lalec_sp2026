---

marp: true
title: Linear Algebra
theme: default
paginate: true
html: true
sanitize: false

---

# 🔢 Linear Algebra (MATH-222) 

## 🎓 Dr. Aamir Alaud Din 

### **Topic 7 - Permutations and Symmetry**

---

# 📋 Table of Contents 

### **Objectives**
### **The Why Section**
### **Permutations**
### **Symmetry**
### **Summary**

---

# 🎯 Objectives

By the end of this topic you will be able to:

- Explain permutation matrices and their use.
- Properties of permutation matrices.
- Explain the symmetrical matrices, their formation from $AA^T$.

---

# 🤔 The Why Section

- So far, we discussed the solution to the system of equations, inversion, and $LU$ factorization of matrices and all of them involved elimination matrices, permutation matrices for row and column exchanges, and scaling matrices.
- We don't know how many possiblities exist for row exchanges in an $n \times n$ matrix.
- Then definitely, there must be those number of permutation matrices.
- We want to find all those row swapping possiblities (permutation matrices).

---

# 🤔 The Why Section

- All the matrices have some properties and special matrices have their own properties.
- Special matrices have some properties which are applicable in their own family but not in general.
- We are interested in knowing the properties of permutation matrices.
- We are also interested in knowing how symmetry arises from matrices.

---

# 📝 Board Time

![width:800px](./images/board_time.png)

---

# Summary

- There exist $n!$ permutation matrices of order $n \times n$.
- For permutation matrices $P^{-1} = P^T$.
- Since $P^{-1} = P^T$, $P^{-1}P = PP^{-1} = P^T P = P P^T = I$.
- For an $m \times n$ matrix $A$, the operation $AA^T$ generates a symmetrical matrix.

---

# 🎉 Thanks!

Questions?


