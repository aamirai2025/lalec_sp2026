---

marp: true
title: Linear Algebra
theme: default
paginate: true
html: true
sanitize: false

---

# 🔢 Linear Algebra (MATH-222) 

## 🎓 Dr. Aamir Alaud Din 

### **Topic 5 - Inverse**

---

# 📋 Table of Contents 

### **Objectives**
### **The Why Section**
### **Meaning of Inverse**
### **Inverse of Singular Matrices**
### **Inverse of Non-Singular Matrices**
### **Summary**

---

# 🎯 Objectives

By the end of this topic you will be able to:

- Explain the physical meaning of inverse matrices.
- Explain why inverse doesn't exist for non-invertible matrices.
- Explain why inverse exist for invertible matrices and how to find inverse.

---

# 🤔 The Why Section

- For general mathematical functions, there exist functions which undo the operations of the functions which are called inverse functions.
- Do the inverse functions also exist in matrices for their corresponding functions?
- There may be square matrices for which inverse don't exist.
- What type of matrices have no inverse and what is the reason of non-existence of inverse?
- There are also matrices for which inverse exist and how to compute the inverse matrices?

---

# 📝 Board Time

![width:800px](./images/board_time.png)

---

# Summary

- Inverse matrices undo the operations of their corresponding transformation matrices.
- For matrices having dependent rows or columns, the inverse don't exist and these matrices are non-invertible matrices.
- The matrices having independent rows and columns are the invertible matrices and inverse exist for these matrices.
- The idea of Gauss-Jordan for solution of system of equations can be used to find inverse of invertible matrices.

---

# 🎉 Thanks!

Questions?


