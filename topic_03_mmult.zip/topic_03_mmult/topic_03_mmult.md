---

marp: true
title: Linear Algebra
theme: default
paginate: true
html: true
sanitize: false

---

# 🔢 Linear Algebra (MATH-222) 

## 🎓 Dr. Aamir Alaud Din 

### **Topic 3 - Matrix Multiplication**

---

# 📋 Table of Contents 

### **Objectives**
### **The Why Section**
### **Higher Dimensions**
### **Methods of Matrix Multiplication**
### **The Laws on Matrix Multiplication**
### **Summary**

---

# 🎯 Objectives

By the end of this topic you will be able to:

- Discuss the higher dimensions and dot product in higher dimensions.
- Multiply matrices in three different ways.
- Manipulate the matrices with matrix multiplication.
- Describe and use the laws on matrix multiplication.

---

# 🤔 The Why Section

![width:1200](./images/store.png)

- How to get the daily sales and the total sale for the year?
- Matrix multiplication is one of the fundamental and most important topics.
- Nearly all matrix operations and applications involve matrix multiplication.
- There is not only one method of matrix multiplication.

---

# 🤔 The Why Section

- Several methods of matrix multiplication exist, however, we will learn only three methods which are sufficient not only for the coverage of the course but also for majority of topics involving matrix multiplication.
- If we want to get a specific row in the product matrix, how can we get it without multiplying the complete matrices?
- If we want to get a specific column in the product matrix, how can we get it without multiplying the complete matrices?
- If we want to get a specific entry in the product matrix, how can we get it without multiplying the matrices completely?
- We learn these techniques now.

---

# 🌌 Higher Dimensions

- The usual world of 3D
- The world of higher dimensions
- [The tesseract: 4D hypercube](https://en.wikipedia.org/wiki/Tesseract)
- [String theory: 11D world in multiuniverse concept](https://www.youtube.com/watch?v=jI50HN0Kshg)

---

# 📝 Board Time

![width:800px](./images/board_time.png)

---

# 💡 Summary

- The dot product is important in matrix multiplication.
- The element $c_{ij}$ in the product $C=AB$ is obtained by multiplying _i_<sup>th</sup> row of $A$ by _j_<sup>th</sup> column of $B$.
- The _j_<sup>th</sup> column in the product matrix $C=AB$ is obtained by multiplying matrix $A$ with _j_<sup>th</sup> column of $B$.
- The _j_<sup>th</sup> row in the product matrix $C=AB$ is obtained by multiplying _j_<sup>th</sup> row of matrix $A$ by matrix $B$.
- The matrices which perfom the row operations are called elimination matrices.

---

# 🎉 Thanks!

Questions?


