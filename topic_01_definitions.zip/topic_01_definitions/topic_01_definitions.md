---

marp: true
title: Linear Algebra
theme: default
class: invert
paginate: true
html: true
sanitize: false

---

# 🔢 Linear Algebra (MATH-222) 

## 🎓 Dr. Aamir Alaud Din 

### **Topic 1 - Definitions**

### **January 19, 2026**

---

# 📋 Table of Contents 

### **Objectives**
### **The Why Section**
### **Definitions**
### **Addition and Subtraction of Matrices**
### **Summary**

---

# 🎯 Objectives

By the end of this topic you will be able to:

- Describe matrices in your own words
- Describe different types of matrices in your own words
- Add and subtract matrices

---

# 🤔 The Why Section

- During this course, you will encounter many new topics like eigenvalues and eigenvectors.
- They can be computed for square matrices only and for this purpose we must know what is a square matrix.
- Independent scaling of vectors is possible through diagonal matrices only and therefore we must know what is a diagonal matrix.
- If we don't know different types of matrices, we can't use them properly.
- So, definitions are required and we are going to learn them.

---

# Definitions: **Matrix**

A matrix is a collection of numbers arranged in rows and columns.

- Horizontal arrangement of numbers is row
- Vertical arrangement of numbers is column
- Representation with capital letters e.g., $A$ and $X$ etc.
- A matrix of 2 rows and 3 columns is

$$
A = \begin{pmatrix}
2 & -3 & 4 \\
1 & 0 & -9
\end{pmatrix}
$$

---

# Definitions: **Matrix**

- General representation of an $m \times n$ matrix $A$ is

$$
A = [a_{ij}]
$$

- The order of the matrix is $m \times n$
- $m$ rows
- $n$ columns

---

# Definitions: **Square and Rectangular Matrices**

- An $m \times n$ matrix is square if $m = n$ and rectangular if $m \ne n$.

$
A = 
\begin{pmatrix}
2 & 3 & 6 \\
1 & -1 & 0 \\
3 & 2 & -7
\end{pmatrix}
$ is a square matrix with 3 rows and 3 columns
\
$
B = 
\begin{pmatrix}
-2 & 1 & 6 \\
1 & -2 & 0 
\end{pmatrix}
$ is a rectangular matrix with 2 rows and 3 columns

---
# Definitions: **Row Vector**

- An $m \times n$ matrix with $m = 1$ or a matrix of order $1 \times n$ is called a row vector.
- The above row vector has n columns.
- The $1 \times 4$ row vector $\begin{pmatrix}2 & 0 & -7 & 2\end{pmatrix}$ is a row vector with 4 columns.
- The row vector is written in bold lowercase letters _e.g.,_ $\textbf{b}$ and $\textbf{x}$ etc.

---

# Definitions: **Column Vector**

- An $m \times 1$ matrix or a matrix of order $m \times 1$ is called a column vector.
- The above column vector has $m$ rows.
- The $3 \times 1$ column vector $\begin{pmatrix}-7 \\ 1 \\ 6 \end{pmatrix}$ is a column vector with 3 rows.
- The column vectors are also written as bold lowercase letters just like the row vectors.

---

# Definitions: **Null or Zero Matrix**

- A matrix all whose elements are zero is called a null or zero matrix.
- The null matrix is usually represented by $O$.
- A $2 \times 3$ null matrix is

$$
O = \begin{pmatrix}
0 & 0 & 0 \\
0 & 0 & 0
\end{pmatrix}
$$

- Generally,

$$
O_{m \times n} = \begin{pmatrix}
a_{ij}
\end{pmatrix}
$$

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;where $a_{ij} = 0\;\;\; \forall \;\; i, j$

---

# Definitions: **Unit or Unity or Identity Matrix**

- An square matrix $\begin{pmatrix} a_{ij} \end{pmatrix}$ of order $n \times n$ with $a_{ij} = 1 \; \forall \; i=j$ and $a_{ij} = 0 \; \forall \; i \ne j$ is called a unit or unity or identity matrix.
<br>
- The matrix $\begin{pmatrix}1 & 0 & 0 \\ 0 & 1 & 0 \\ 0 & 0 & 1 \end{pmatrix}$ is a $3 \times 3$ identity matrix.
<br>
- An identity matrix is 1 of matrices.

---

# Definitions: **Diagonal Elements of a Square Matrix and Diagonal Matrix**

- If $A = \begin{pmatrix} a_{ij} \end{pmatrix}$ is a square matrix of order $n \times n$, then all the elements $a_{ij}$ with $i = j$ are the diagonal elements of the matrix.

- A square matrix with $a_{ij}=0 \; \forall \;i \ne j$ is called a diagonal matrix.

- The matrix $\begin{pmatrix} 3 & 0 & 0 \\ 0 & 1 & 0 \\ 0 & 0 & 2 \end{pmatrix}$ is a diagonal matrix.

---

# Definitions: **Scalar Matrix**

- A diagonal matrix all whose elements are the same is called a scalar matrix.
- The matrix $\begin{pmatrix} -3 & 0 & 0 \\ 0 & -3 & 0 \\ 0 & 0 & -3 \end{pmatrix}$ is a $3 \times 3$ scalar matrix.

---

# Definitions: **Transposed Matrix**

- A square matrix $B$ obtained by writing rows of $A$ into columns of $B$ is transposed matrix.
<br>
- The matrix $B = \begin{pmatrix} 1 & 2 & 3 \\ 4 & 5 & 6 \\ 7 & 8 & 9 \end{pmatrix}$ is transpose of $A = \begin{pmatrix} 1 & 4 & 7 \\ 2 & 5 & 8 \\ 3 & 6 & 9 \end{pmatrix}$
<br>
- A transposed row vector will be a column vector and vice versa.
- Transpose of a matrix $A$ is usually represented by $A^T$.

---

# Definitions: **Symmetric Matrix**

- A matrix $A$ is a symmetric matrix if $A^T = A$.
- The elements of a symmetric matrix are mirrored across the main diagonal _i.e.,_ $a_{ij}=a_{ji}$.
<br>
- The matrix $A = \begin{pmatrix} 1 & 2 \\ 2 & 4 \end{pmatrix}$ is symmetric because $A^T = \begin{pmatrix} 1 & 2 \\ 2 & 4 \end{pmatrix} = A$
<br>

---

# Definitions: **Anti-Symmetric Matrix**

- A square matrix $A$ is anti-symmetric or skew-symmetric matrix if $A^T = -A$.
<br>
- The matrix $A = \begin{pmatrix} 0 & 5 & -2 \\ -5 & 0 & 1 \\ 2 & -1 & 0 \end{pmatrix}$ is anti-symmetric because 
<br> $A^T = \begin{pmatrix} 0 & 5 & -2 \\ -5 & 0 & 1 \\ 2 & -1 & 0 \end{pmatrix} = - A$

---

# Addition and Subtraction of Matrices

- Two matrices are conformable for addition and subtraction if they have the same order.
- The corresponding element of the matrices are added or subtracted.
- The null matrix is the additive identity of a matrix of the same order _i.e.,_ it behaves like $0$ of numbers.
- The matrix addition is commutative _i.e.,_ $A + B = B + A$.
- The matrix addition follows associative rule _i.e.,_ $(A + B) + C = A + (B + C)$.

---

# 🎉 Thanks!

Questions?


