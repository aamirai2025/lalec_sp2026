---

marp: true
title: Linear Algebra
theme: default
paginate: true
html: true
sanitize: false

---

# 🔢 Linear Algebra (MATH-222) 

## 🎓 Dr. Aamir Alaud Din 

### **Topic 2 - Solving System of Linear Equations**

---

# 📋 Table of Contents 

### **Objectives**
### **The Why Section**
### **Solving System of Linear Equations: The Row Way**
### **Solving System of Linear Equations: The Column Way**
### **Introduction to Bad Systems**
### **Summary**

---

# 🎯 Objectives

By the end of this topic you will be able to:

- Solve and look into the solution of the system of linear equations, the row way.
- Solve and look into the solution of the system of linear equations, the column way.
- Describe bad systems of equations.

---

# 🤔 The Why Section

![width:800px](./images/fruits_system.png)

---

# 🤔 The Why Section

- Solving system of linear equations is not the goal of the course but it is the heart and core of the subject and is the fundamental problem of linear algebra.
- Many machine learning models, AI models, and artificial neural networks heavily rely on solving system of linear equations.
- Balancing chemical reactions and solving electrical circuits (Kirchhoff's Law) involve solving system of linear equations.
- In addition to solution, we will also see the mechanics of solution.

---

# 📝 Board Time

![width:800px](./images/board_time.png)

---

# 🔢 System Representation

- What we already know is

$$
\begin{pmatrix}
1 & -2 \\
3 & 2
\end{pmatrix}
\begin{pmatrix}
x \\
y
\end{pmatrix}
=
\begin{pmatrix}
1 \\
11
\end{pmatrix}
$$

- In matrix notation, we write

$$
A \textbf{x} = \textbf{b} \;\;\;\;\;\; \text{or} \;\;\;\;\;\; A \vec{x} = \vec{b}
$$

- This representation is for the row picture.

---

# 🔢 System Representation

- Equivalently, we can write the system as follows

$$
x
\begin{pmatrix}
1 \\
3
\end{pmatrix}
+y
\begin{pmatrix}
-2 \\
2
\end{pmatrix}
=
\begin{pmatrix}
1 \\
11
\end{pmatrix}
$$

<br>

- This is the linear combination of the columns $\begin{pmatrix} 1 \\ 3 \end{pmatrix}$  and $\begin{pmatrix} -2 \\ 2 \end{pmatrix}$.

- The right combination $x=3$ and $y=1$ gives the right hand side $\textbf{b} = \begin{pmatrix} 1 \\ 11 \end{pmatrix}$.

---

# 🤔 Question

- If I change the right hand side _i.e.,_ $\textbf{b} = \begin{pmatrix} 1 \\ 11 \end{pmatrix}$ to some other vector, say $\textbf{b} = \begin{pmatrix} 3 \\ -1 \end{pmatrix}$, can I get the right linear combination $x \begin{pmatrix} 1 \\ 3 \end{pmatrix} +y \begin{pmatrix} -2 \\ 2 \end{pmatrix}$ to get $\textbf{b} = \begin{pmatrix} 3 \\ -1 \end{pmatrix}$?

---

# 🤔 Question

- If I change the right hand side _i.e.,_ $\textbf{b} = \begin{pmatrix} 1 \\ 11 \end{pmatrix}$ to some other vector, say $\textbf{b} = \begin{pmatrix} 3 \\ -1 \end{pmatrix}$, can I get the right linear combination $x \begin{pmatrix} 1 \\ 3 \end{pmatrix} +y \begin{pmatrix} -2 \\ 2 \end{pmatrix}$ to get $\textbf{b} = \begin{pmatrix} 3 \\ -1 \end{pmatrix}$?
- Which right hand sides (which $\textbf{b}s$) are allowed so that the system has a solution?

---

# ☝️ Solution

🔐 If the column vectors on the left side lie on the same line, and the right side $\textbf{b}$ is on the same line, we have infinitely many solutions.
🔒 If the column vectors of the left side lie on the same line but the right side vector $\textbf{b}$ is not on that line, we don't have a solution at all.

---

# 💡 Summary

- The row picture solves a system of equations by taking one equation at a time and the solution is where the lines meet.
- We draw first line (one equation) and then draw the second line (the other equation) and intersection is the solution.
- The column picture solves the system of equations by taking the right combination of the columns on the left side.
- Some systems have infinitely many solutions and some have no solution at all.

---

# 🎉 Thanks!

Questions?


