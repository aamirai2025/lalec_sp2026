import numpy as np
import matplotlib.pyplot as plt


def eq(x):
    y1 = (x - 1)/2
    y2 = (11 - 3*x)/2
    return y1, y2

x = np.array([1, 4])
y = eq(x)

plt.plot(x, y[0], '-b', linewidth=2)
plt.plot(x, y[1], '-g', linewidth=2)
plt.plot([3, 3], [0, 1], '--r')
plt.plot([0, 3], [1, 1], '--r')
plt.scatter(3, 1, s=40, c='r')
plt.xlim([0, 5])
plt.ylim([0, 5])
plt.xlabel("X-axis", size=18, weight='bold')
plt.ylabel("Y-axis", size=18, weight='bold')
plt.xticks(size=18, weight='bold')
plt.yticks(size=18, weight='bold')
plt.tight_layout()
plt.show()