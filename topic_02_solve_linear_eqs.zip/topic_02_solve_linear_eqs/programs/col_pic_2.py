import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
from numpy.linalg import norm

fig, ax = plt.subplots()

# Each start/end MUST be (x,y)
s1, e1 = (0, 0), (1, 3)
s2, e2 = (0, 0), (-2, 2)
s3, e3 = (0, 0), (1, 11)
s4, e4 = (0, 0), (3, 9)

# Draw arrows — head is included in total length; mutation_scale auto-scales
arrow1 = FancyArrowPatch(s1, e1, arrowstyle='-|>',
                         mutation_scale=norm([1, 3]) * 5, color='k')
arrow2 = FancyArrowPatch(s2, e2, arrowstyle='-|>',
                         mutation_scale=norm([-2, 2]) * 5, color='k')
arrow3 = FancyArrowPatch(s3, e3, arrowstyle='-|>',
                         mutation_scale=norm([1, 11]) * 2, color='k')
arrow4 = FancyArrowPatch(s4, e4, arrowstyle='-|>',
                         mutation_scale=norm([3, 9]) * 2, color='k')

ax.add_patch(arrow1)
ax.add_patch(arrow2)
ax.add_patch(arrow3)
ax.add_patch(arrow4)
plt.plot([-2, 1], [2, 11], '--r')
plt.plot([1, 3], [11, 9], '--r')

ax.set_aspect('equal')
ax.set_xlim(-3, 4)
ax.set_ylim(0, 12)
plt.xticks(size=18, weight='bold')
plt.yticks(size=18, weight='bold')
plt.show()
