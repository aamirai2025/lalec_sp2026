import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

# Coefficient matrix and RHS
A = np.array([[1,2,3],
              [2,5,2],
              [6,-3,1]])
b = np.array([6,4,2])

# Intersection point of the three planes
pt = np.linalg.solve(A, b)

# Create a grid of x,y values
xx, yy = np.meshgrid(np.linspace(-2, 4, 20),
                     np.linspace(-2, 4, 20))

# Compute z values for each plane
zz1 = (6 - xx - 2*yy) / 3
zz2 = (4 - 2*xx - 5*yy) / 2
zz3 = (2 - 6*xx + 3*yy)

# Plotting
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

ax.plot_surface(xx, yy, zz1, alpha=0.5, color='blue')
ax.plot_surface(xx, yy, zz2, alpha=0.5, color='green')
ax.plot_surface(xx, yy, zz3, alpha=0.5, color='yellow')

# Plot intersection point
ax.scatter(pt[0], pt[1], pt[2], s=80, color='red')

ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')

plt.show()
