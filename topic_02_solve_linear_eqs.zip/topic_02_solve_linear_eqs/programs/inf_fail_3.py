import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

# Set up figure
fig = plt.figure(figsize=(12, 10))

# ==== ROW PICTURE: INFINITE SOLUTIONS (three identical planes) ====
xx, yy = np.meshgrid(np.linspace(-4, 4, 20), np.linspace(-4, 4, 20))
zz_inf = (4 - xx - yy) / 2  # plane

ax1 = fig.add_subplot(221, projection='3d')
for _ in range(3):
    ax1.plot_surface(xx, yy, zz_inf, alpha=0.4)
ax1.set_title("Row Picture (Infinite Solutions)")
ax1.set_xlabel('x'); ax1.set_ylabel('y'); ax1.set_zlabel('z')

# ==== ROW PICTURE: NO SOLUTION (three parallel planes) ====
zz1 = (4 - xx - yy) / 2
zz2 = (6 - xx - yy) / 2
zz3 = (8 - xx - yy) / 2

ax2 = fig.add_subplot(222, projection='3d')
for zz in [zz1, zz2, zz3]:
    ax2.plot_surface(xx, yy, zz, alpha=0.4)
ax2.set_title("Row Picture (No Solution)")
ax2.set_xlabel('x'); ax2.set_ylabel('y'); ax2.set_zlabel('z')

# ==== COLUMN PICTURE: INFINITE SOLUTIONS (RHS in span) ====
ax3 = fig.add_subplot(223, projection='3d')
v1 = np.array([1,0,1])
v2 = np.array([2,0,2])
v3 = np.array([3,0,3])
rhs = np.array([4,0,4])

for v in [v1,v2,v3]:
    ax3.quiver(0,0,0, v[0],v[1],v[2])
ax3.scatter(rhs[0],rhs[1],rhs[2], s=60)
ax3.set_xlim(0,5); ax3.set_ylim(0,5); ax3.set_zlim(0,5)
ax3.set_title("Column Picture (Infinite Solutions)")
ax3.set_xlabel('x'); ax3.set_ylabel('y'); ax3.set_zlabel('z')

# ==== COLUMN PICTURE: NO SOLUTION (RHS outside span) ====
ax4 = fig.add_subplot(224, projection='3d')
for v in [v1,v2,v3]:
    ax4.quiver(0,0,0, v[0],v[1],v[2])
rhs2 = np.array([2,2,2])  # off the line
ax4.scatter(rhs2[0],rhs2[1],rhs2[2], s=60)
ax4.set_xlim(0,5); ax4.set_ylim(0,5); ax4.set_zlim(0,5)
ax4.set_title("Column Picture (No Solution)")
ax4.set_xlabel('x'); ax4.set_ylabel('y'); ax4.set_zlabel('z')

plt.tight_layout()
plt.show()
