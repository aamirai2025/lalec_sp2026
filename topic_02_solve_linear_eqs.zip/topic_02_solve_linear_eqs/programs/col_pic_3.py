import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D   # noqa: F401
import numpy as np

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

ax.quiver(0, 0, 0, 1, 2, 6, arrow_length_ratio=0.1, lw=2, color='r')
ax.quiver(0, 0, 0, 2, 5, -3, arrow_length_ratio=0.1, lw=2, color='g')
ax.quiver(0, 0, 0, 3, 2, 1, arrow_length_ratio=0.1, lw=2, color='b')
ax.quiver(0, 0, 0, 6, 4, 2, arrow_length_ratio=0.1, lw=2, color='k')
ax.set_xlim(0,14)
ax.set_ylim(0,10)
ax.set_zlim(-4,7)
ax.set_xlabel("X", size=18, weight='bold')
ax.set_ylabel("Y", size=18, weight='bold')
ax.set_zlabel("Z", size=18, weight='bold')
ax.tick_params(labelsize=18)
plt.show()