---

marp: true
title: Linear Algebra
theme: default
paginate: true
html: true
sanitize: false

---

# Linear Algebra (MATH-222) 🔢

## Dr. Aamir Alaud Din 🎓

### **Topic 0 - Prelude**

---

# 🎯 Objectives

By the end of this session you will:

- Know about the instructor and the course
- Understand class rules which are important
- Know the lecture format of all the lectures
- Know assessments to conclude the course
- Understand the scope and importance of the course
- Keys to be successful in the course

---

# About the Instructor

## Dr. Aamir Alaud Din

### **Undergraduate:** BE Chemical Engineering, PU, Lahore

### **Graduate:** MS Environmental Engineering, South Korea

### **Postgraduate:** PhD Environmental Engineering, South Korea

---

# Courses of Interest: Technical

- Computer Programming (Python, C++, MATLAB, R, Julia, and many more)
- Artificial Intelligence and Machine Learning
- Deep Learning and Artificial Neural Networks
- Data Science
- Linear Algebra
- Numerical Methods
- Differential Equations
- Calculus

---

# About the Course

- Basic breadth - Introductory
- Interesting course
- Logics
- One of the most applied course
- Mostly board hardly slides
- Topical and not sessional

---

# Class Rules

- **Attendance**
  - Attend to learn
  - 75% attendance is mandatory to appear in ESE
- **Inside Class**
  - Silence - Instructor knows better than students mostly
  - No use of cell phones
  - Eating and drinking without noise (no major meal please)
  - Relevant questions during the lectures is allowed by raising hand
- **Penalty**
  - Reduction of 50% marks in quiz

---

# Lecture Format

- Topical
- Objectives
- The Why Section (Optional)
- Topic with Example
- Summary

---

# Assessments

## Minor Assessments

- **Quizzes**
  - 2 to 3
  - Unannounced
  - Last two topics
- **Assignments**
  - 2 to 3
  - Zero marks after the deadline
  - Deadline is one week in the same day class of next week

------

# Assessments

## Major Assessments

- **One Hour Tests (OHTs)**
  - OHT-1
  - OHT-2
- **End Semester Exam (ESE)**
  - ESE
- All the assessments as per policy
- 🏋 $\ne$ 🧍‍♂️

---

# Importance and Scope

- History
  - Theoretical
  - Theorems and Proofs
  - Limited Applications
- Current Status
  - Applied
  - Examples
  - Applications in chemistry, physics, biology, computer science, engineering, AI, ML, DL, data science, statistics, business, and social sciences

---

# Keys to Success 🔑

1) Learn

---

# Keys to Success 🔑

1) Learn
2) Practice

---

# Keys to Success 🔑

1) Learn
2) Practice
3) Practice

---

# Keys to Success 🔑

1) Learn
2) Practice
3) Practice
4) Practice

### **Practice, practice, and practice!!!**

---

# 🎉 Thanks!

Questions?


