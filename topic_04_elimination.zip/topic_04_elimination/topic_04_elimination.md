---

marp: true
title: Linear Algebra
theme: default
paginate: true
html: true
sanitize: false

---

# 🔢 Linear Algebra (MATH-222) 

## 🎓 Dr. Aamir Alaud Din 

### **Topic 4 - Elimination**

---

# 📋 Table of Contents 

### **Objectives**
### **The Why Section**
### **Mechanics of Solution**
### **Elimination and Failure**
### **Summary**

---

# 🎯 Objectives

By the end of this topic you will be able to:

- Explain the mechanics of solution to the system of equations.
- Use elimination to solve systems of equations.
- Explain when elimination fails temporarily and to get rid of this situation.

---

# 🤔 The Why Section

- We learnt to solve the system of equations by 1) simultaneous solution and 2) using matrices.
- Although, solution is the same, but is there any difference between these solution mechanically?
- We also know row operations to solve a system of equations.
- Do the software packages also use row operations to solve system of equations?
- How do the software packages solve a system of equations?
- Why do we use matrices to solve the system of equations when we already have the method of solving system simultaneously?

---

# 📝 Board Time

![width:800px](./images/board_time.png)

---

# Summary

- Mechanically the solution to the system of equations in anyway is the same.
- Software packages use elimination matrices in place of row operations.
- To get rid of a failure, permutation matrices play their role.
- The solution must be validated before publishing the results.

---

# 🎉 Thanks!

Questions?


