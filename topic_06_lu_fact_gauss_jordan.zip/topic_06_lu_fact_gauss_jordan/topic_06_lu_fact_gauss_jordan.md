---

marp: true
title: Linear Algebra
theme: default
paginate: true
html: true
sanitize: false

---

# 🔢 Linear Algebra (MATH-222) 

## 🎓 Dr. Aamir Alaud Din 

### **Topic 6 - $A = LU$ Factorization and Gaussian Elimination**

---

# 📋 Table of Contents 

### **Objectives**
### **The Why Section**
### **Gauss Jordan Method**
### **$A = LU$ Factorization**
### **Summary**

---

# 🎯 Objectives

By the end of this topic you will be able to:

- Solve the system of equations without back substitution.
- Factorize the matrices into upper and lower triangular matrices.

---

# 🤔 The Why Section

- In Gaussian elimination method, we are able to solve the system of equations.
- The method converts the coefficient matrix to the upper triangular matrix which after back substitution gives the solution to the system of equations.
- Gauss Jordan method guarantees no back substitution and solution to multiple right hand sides given the system remains the same and the system is a good system.
- We will look into this method with example.

---

# 🤔 The Why Section

- Given the equations $x^2 + 5x + 6 = 0$, we can write it as $(x + 2)(x+3) = 0$
- In the same way, can I factorize a matrix into product matrices.
- In other words, if I have the matrix $A$, can I write it as a product of two matrices _i.e.,_ $A = BC$?
- We will see how to factorize a matrix.

---

# 📝 Board Time

![width:800px](./images/board_time.png)

---

# Summary

- Gauss Jordan method confirms the solution to the system of equations and multiple systems without back substitution given
  - The system is a good system (not bad)
  - The system remains the same
- A matrix can be factorized into lower and upper triangular matrices such that their product gives back the original matrix.
- The system can be solved on Microsoft Excel.

---

# 🎉 Thanks!

Questions?


